public interface Constants {
     
    int terminal_number = 19;
    int variable_number = 11;
     
    String[] terminals = { "{", "}", ":", "=" , "x", "y", "a" ,"b", "(", ")", ";", "i", "f", "e", "l", "s", "e", "<", ">"};
    String[] variables = { "S", "L", "E", "R", "A", "T", "V", "C", "Q", "O" , "$" };
    
    
 
}